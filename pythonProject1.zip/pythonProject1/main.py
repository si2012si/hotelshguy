import telebot
from telebot import types
import random
# Токен вашего бота
TOKEN = '6412427617:AAHvri3GcgINdiUZfAiLokyU0PjuEhFxG4Q'
# Создание экземпляра бота
bot = telebot.TeleBot(TOKEN)
# Список хотелок
def read_hotels_from_file():
    hotels = []
    # Открытие файла для чтения
    with open("hotels.txt", "r") as file:
        # Чтение каждой строки файла и добавление ее в список
        for line in file:
            hotels.append(line.strip())
    return hotels
hotels = read_hotels_from_file()
# Регистрация команды /start
@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("Отправить хотелку")
    btn2 = types.KeyboardButton("Получить хотелку")

    markup.add(btn1, btn2)
    bot.send_message(message.chat.id, "Привет! Чем я могу тебе помочь?", reply_markup=markup)
# Обработка нажатия кнопки "Отправить хотелку"

# Обработка нажатия кнопки "Отправить хотелку"
@bot.message_handler(func=lambda message: message.text == "Отправить хотелку")
def send_wish(message):

    bot.send_message(message.chat.id, "Введи имя и, что ты хочешь?")
    bot.register_next_step_handler(message, add_wish)
# Обработка полученной хотелки
def add_wish(message):

    wish = message.text
    hotels.append(wish)
    # Открытие файла для записи
    with open("hotels.txt", "a") as file:
        file.write(wish + "\n")
    bot.send_message(message.chat.id, "Хотелка успешно добавлена!")
# Обработка нажатия кнопки "Получить хотелку"
@bot.message_handler(func=lambda message: message.text == "Получить хотелку")
def get_wish(message):
    if len(hotels) > 0:
        random_wish = random.choice(hotels)

        bot.send_message(message.chat.id, f"Вот одна из хотелок: {random_wish}")
    else:
        bot.send_message(message.chat.id, "Еще нет ни одной хотелки")
# Запуск бота
bot.polling(none_stop=True)